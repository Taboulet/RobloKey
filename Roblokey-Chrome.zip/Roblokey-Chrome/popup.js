// popup.js

document.addEventListener('DOMContentLoaded', () => {
  const codeDiv = document.getElementById('code');
  const errorDiv = document.getElementById('error');
  const copyBtn = document.getElementById('copyBtn');

  codeDiv.addEventListener('click', async () => {
    codeDiv.textContent = 'Searching...';
    errorDiv.textContent = '';
    copyBtn.style.display = 'none';
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const [{ result, error }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Find all elements with a src attribute starting with 'roblox-player:'
          const nodes = Array.from(document.querySelectorAll('[src^="roblox-player:"]'));
          for (const node of nodes) {
            const src = node.getAttribute('src');
            if (src && src.startsWith('roblox-player:')) {
              return src;
            }
          }
          return null;
        },
      });
      if (error) throw new Error(error);
      if (result) {
        codeDiv.textContent = result;
        copyBtn.style.display = 'inline-block';
      } else {
        codeDiv.textContent = '(Not found)';
        copyBtn.style.display = 'none';
      }
    } catch (e) {
      codeDiv.textContent = '';
      errorDiv.textContent = 'Error: ' + e.message;
      copyBtn.style.display = 'none';
    }
  });

  copyBtn.addEventListener('click', () => {
    const code = codeDiv.textContent;
    if (code && code !== '(Not found)' && code !== '(Click to find)' && code !== 'Searching...') {
      navigator.clipboard.writeText(code);
      copyBtn.textContent = 'Copied!';
      setTimeout(() => (copyBtn.textContent = 'Copy'), 1200);
    }
  });
});
